#!/tmp/tools/bash

PATH="/tmp/tools:${PATH}"
export PATH=$PATH

LOG_DIR='/sdcard/.gio4pda'
LOG_FILE="$LOG_DIR/batch-log.txt"

BATCH_DIR='/sdcard/gio4pda'
BATCH_COMMAND='/cache/recovery/extendedcommand'
#BATCH_COMMAND="$LOG_DIR/batch-command.txt"

SELF='-processor'


#######################################################################

rm $BATCH_COMMAND
if [ -f $PROP_FILE ]; then rm $PROP_FILE; fi

#######################################################################

if [ ! -d $LOG_DIR ]; then
    mkdir -p $LOG_DIR
fi

#######################################################################

if [ -d $BATCH_DIR ]; then

    REMOVING=''
    UPDATING=''
    PATCHING=''
    TOTAL=''

    #######################################################################

    FILES="$(ls $BATCH_DIR | grep '.zip' | grep -v -i \"$BATCH_DIR\" | grep -v -i \"$SELF\")"

    if [ -n "$FILES" ]; then

        for FILE in $FILES; do
            if [ -n "$(echo $FILE | grep -i '\-remover')" ]; then
                REMOVERS="$REMOVERS $FILE"
            elif [ -n "$(echo $FILE | grep -i '\-patch')" ]; then
                PATCHERS="$PATCHERS $FILE"
            else
                UPDATERS="$UPDATERS $FILE"
            fi
        done

        #######################################################################

        echo "REMOVERS:"	> $LOG_FILE
        echo $REMOVERS		>> $LOG_FILE
        echo -e '\n'		>> $LOG_FILE
        echo "UPDATERS:"	>> $LOG_FILE
        echo $UPDATERS		>> $LOG_FILE
        echo -e '\n'		>> $LOG_FILE
        echo "PATCHERS:"	>> $LOG_FILE
        echo $PATCHERS		>> $LOG_FILE

        #######################################################################

        if [ -n "$REMOVERS" ]; then
            TOTAL="$TOTAL $REMOVERS"
        fi

        if [ -n "$UPDATERS" ]; then
            TOTAL="$TOTAL $UPDATERS"
        fi

        if [ -n "$PATCHERS" ]; then
            TOTAL="$TOTAL $PATCHERS"
        fi

        #######################################################################

        TOTAL="$(echo $TOTAL | sed -e 's/\ \ /\ /g' | sed -e 's/\ \ /\ /g' | sed -e 's/\ \ /\ /g' | sed -e 's/\ \ /\ /g')"

        #######################################################################

        if [ -n "$TOTAL" ]; then

            touch $BATCH_COMMAND

            for ITEM in $TOTAL; do
                echo "ui_print(\"Processing: $ITEM\");" >> $BATCH_COMMAND
                echo "install_zip(\"/sdcard/gio4pda/$ITEM\");" >> $BATCH_COMMAND
            done

            /sbin/setprop gio4pda.batch 1
            echo "Will install $TOTAL" >> $LOG_FILE

            sync

        else
            /sbin/setprop gio4pda.nopackges 1
            /sbin/setprop gio4pda.batch 0

        fi

    else
        /sbin/setprop gio4pda.nofiles 1
        /sbin/setprop gio4pda.batch 0

    fi

#######################################################################

else
    echo "Nothing to install. Exiting" > $LOG_FILE
    touch $PROP_FILE
    /sbin/setprop gio4pda.batch 0
    /sbin/setprop gio4pda.nofolder 1
fi
